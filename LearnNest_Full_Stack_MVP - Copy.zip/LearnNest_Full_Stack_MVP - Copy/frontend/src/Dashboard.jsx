import { useEffect, useState } from "react";

function Dashboard({ setPage }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");

    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    window.location.reload();
  };

  return (
    <div className="dashboard">

      {/* Navbar */}
      <nav className="dashboard-navbar">

        <div className="logo">
          📚 Learn<span>Nest</span>
        </div>

        <div className="dashboard-user">
          <span>
            👋 {user?.name || "Student"}
          </span>

          <button onClick={handleLogout}>
            Logout
          </button>
        </div>

      </nav>

      {/* Welcome */}
      <section className="dashboard-welcome">

        <p>STUDENT DASHBOARD</p>

        <h1>
          Welcome back, {user?.name || "Student"}! 👋
        </h1>

        <span>
          Ready to learn something new today?
        </span>

      </section>

      {/* Feature Cards */}
      <section className="dashboard-grid">

        {/* Digital Library */}
        <div className="dashboard-card">
          <div className="dashboard-icon">📚</div>

          <h2>Digital Library</h2>

          <p>
            Search books, borrow available books and reserve books.
          </p>

          <button onClick={() => setPage("library")}>
            Explore Library →
          </button>
        </div>

        {/* My Books */}
        <div className="dashboard-card">
          <div className="dashboard-icon">📖</div>

          <h2>My Books</h2>

          <p>
            View your borrowed books and return them when finished.
          </p>

          <button>
            View My Books →
          </button>
        </div>

        {/* Study Rooms */}
        <div className="dashboard-card">
          <div className="dashboard-icon">👥</div>

          <h2>Study Rooms</h2>

          <p>
            Join a study room and learn together with other students.
          </p>

          <button>
            Find Study Rooms →
          </button>
        </div>

        {/* Discussions */}
        <div className="dashboard-card">
          <div className="dashboard-icon">💬</div>

          <h2>Discussions</h2>

          <p>
            Ask doubts and discuss topics with your study group.
          </p>

          <button>
            Open Discussions →
          </button>
        </div>

        {/* Study Timer */}
        <div className="dashboard-card">
          <div className="dashboard-icon">⏱️</div>

          <h2>Study Timer</h2>

          <p>
            Focus on your studies using a Pomodoro-style timer.
          </p>

          <button>
            Start Studying →
          </button>
        </div>

        {/* Progress */}
        <div className="dashboard-card">
          <div className="dashboard-icon">📊</div>

          <h2>My Progress</h2>

          <p>
            Track your reading and study activity.
          </p>

          <button>
            View Progress →
          </button>
        </div>

      </section>

    </div>
  );
}

export default Dashboard;