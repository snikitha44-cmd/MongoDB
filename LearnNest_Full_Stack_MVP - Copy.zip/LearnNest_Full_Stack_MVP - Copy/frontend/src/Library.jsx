import { useEffect, useState } from "react";
import API from "./api";

function Library() {
  const [books, setBooks] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  const loadBooks = async () => {
    try {
      setLoading(true);

      const response = await API.get("/books", {
        params: {
          search,
        },
      });

      setBooks(response.data.books);
    } catch (error) {
      console.error("Library error:", error);

      setMessage(
        error.response?.data?.message ||
        "Unable to load books"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBooks();
  }, [search]);

  const borrowBook = async (bookId) => {
    try {
      const token = localStorage.getItem("token");

      const response = await API.post(
        `/borrow/${bookId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setMessage(response.data.message);

      loadBooks();
    } catch (error) {
      setMessage(
        error.response?.data?.message ||
        "Unable to borrow book"
      );
    }
  };

  const reserveBook = async (bookId) => {
    try {
      const token = localStorage.getItem("token");

      const response = await API.post(
        `/reserve/${bookId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setMessage(response.data.message);
    } catch (error) {
      setMessage(
        error.response?.data?.message ||
        "Unable to reserve book"
      );
    }
  };

  return (
    <div className="library-page">

      {/* Navbar */}
      <nav className="dashboard-navbar">

        <div className="logo">
          📚 Learn<span>Nest</span>
        </div>

        <button
          className="library-back-btn"
          onClick={() => window.history.back()}
        >
          ← Back
        </button>

      </nav>

      {/* Header */}
      <section className="library-header">

        <p>LEARNNEST LIBRARY</p>

        <h1>
          Digital Library 📚
        </h1>

        <span>
          Discover books and start learning.
        </span>

      </section>

      {/* Search */}
      <section className="library-search">

        <input
          type="text"
          placeholder="Search by title, author, category or ISBN..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

      </section>

      {/* Message */}
      {message && (
        <div className="library-message">
          {message}
        </div>
      )}

      {/* Books */}
      <section className="book-grid">

        {loading ? (
          <div className="library-loading">
            Loading books...
          </div>
        ) : books.length === 0 ? (
          <div className="library-empty">
            <h2>No books found 📚</h2>
            <p>Try another search.</p>
          </div>
        ) : (
          books.map((book) => (
            <div
              className="book-card"
              key={book._id}
            >

              <div className="book-cover">
                📖
              </div>

              <div className="book-info">

                <h2>
                  {book.title}
                </h2>

                <p className="book-author">
                  By {book.author}
                </p>

                <span className="book-category">
                  {book.category}
                </span>

                {book.description && (
                  <p className="book-description">
                    {book.description}
                  </p>
                )}

                <div className="book-availability">
                  Available:{" "}
                  <strong>
                    {book.availableCopies}
                  </strong>{" "}
                  / {book.totalCopies}
                </div>

                <div className="book-actions">

                  <button
                    className="borrow-btn"
                    disabled={book.availableCopies < 1}
                    onClick={() => borrowBook(book._id)}
                  >
                    {book.availableCopies > 0
                      ? "Borrow Book"
                      : "Unavailable"}
                  </button>

                  <button
                    className="reserve-btn"
                    onClick={() => reserveBook(book._id)}
                  >
                    Reserve
                  </button>

                </div>

              </div>

            </div>
          ))
        )}

      </section>

    </div>
  );
}

export default Library;