import React, { useState } from "react";
import ReactDOM from "react-dom/client";
import "./style.css";
import API from "./api";
import Login from "./Login";
import Dashboard from "./Dashboard";
import Library from "./Library";

function App() {
  const [page, setPage] = useState(
  localStorage.getItem("token") ? "dashboard" : "home"
);

  // Signup states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [signupMessage, setSignupMessage] = useState("");

  // Signup function
  const handleSignup = async (e) => {
    e.preventDefault();

    try {
      const response = await API.post("/auth/register", {
        name,
        email,
        password,
      });

      setSignupMessage(response.data.message);

      setName("");
      setEmail("");
      setPassword("");

      setTimeout(() => {
        setPage("login");
      }, 1000);
    } catch (error) {
      setSignupMessage(
        error.response?.data?.message || "Registration failed"
      );
    }
  };

  // LOGIN PAGE
  if (page === "dashboard") {
  return <Dashboard setPage={setPage} />;
}

if (page === "library") {
  return <Library />;
}
  if (page === "login") {
    return (
      <div>
        <Login />

        <div className="auth-back">
          <button onClick={() => setPage("home")}>
            ← Back to Home
          </button>
        </div>
      </div>
    );
  }

  // SIGNUP PAGE
  if (page === "signup") {
    return (
      <div className="auth-container">
        <div className="auth-card">

          <h1>Join LearnNest 🚀</h1>

          <p>Create your student account</p>

          <form onSubmit={handleSignup}>

            <input
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />

            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <input
              type="password"
              placeholder="Create password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={6}
              required
            />

            <button type="submit">
              Create Account
            </button>

          </form>

          {signupMessage && (
            <p className="auth-message">
              {signupMessage}
            </p>
          )}

          <button
            className="auth-secondary-btn"
            onClick={() => setPage("login")}
          >
            Already have an account? Login
          </button>

          <button
            className="auth-secondary-btn"
            onClick={() => setPage("home")}
          >
            ← Back to Home
          </button>

        </div>
      </div>
    );
  }

  // HOME PAGE
  return (
    <div className="app">

      {/* NAVBAR */}
      <nav className="navbar">

        <div className="logo">
          📚 Learn<span>Nest</span>
        </div>

        <div className="nav-links">
          <a href="#home">Home</a>
          <a href="#library">Library</a>
          <a href="#rooms">Study Rooms</a>
          <a href="#about">About</a>
        </div>

        <div className="nav-buttons">

          <button
            className="login-btn"
            onClick={() => setPage("login")}
          >
            Login
          </button>

          <button
            className="signup-btn"
            onClick={() => setPage("signup")}
          >
            Sign Up
          </button>

        </div>

      </nav>

      {/* HERO */}
      <section className="hero" id="home">

        <div className="hero-content">

          <p className="welcome">
            WELCOME TO LEARNNEST
          </p>

          <h1>
            Learn Together.
            <br />
            <span>Grow Together.</span>
          </h1>

          <p className="hero-text">
            Your digital library and collaborative study space in one place.
            Discover books, join study rooms, discuss doubts and learn with
            your friends.
          </p>

          <div className="hero-buttons">

            <button
              className="primary-btn"
              onClick={() =>
                document
                  .getElementById("library")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Explore Library →
            </button>

            <button
              className="secondary-btn"
              onClick={() =>
                document
                  .getElementById("rooms")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
            >
              Join a Study Room
            </button>

          </div>

        </div>

        <div className="hero-card">

          <div className="book-icon">
            📚
          </div>

          <h3>
            Study. Connect. Succeed.
          </h3>

          <p>
            Access your resources and collaborate with your learning community.
          </p>

          <div className="stats">

            <div>
              <strong>10K+</strong>
              <span>Books</span>
            </div>

            <div>
              <strong>500+</strong>
              <span>Study Rooms</span>
            </div>

            <div>
              <strong>5K+</strong>
              <span>Learners</span>
            </div>

          </div>

        </div>

      </section>

      {/* FEATURES */}
      <section className="features" id="library">

        <div className="section-heading">

          <p>WHAT YOU CAN DO</p>

          <h2>
            Everything You Need to Learn Better
          </h2>

        </div>

        <div className="feature-grid">

          <div className="feature-card">

            <div className="feature-icon">
              📖
            </div>

            <h3>
              Digital Library
            </h3>

            <p>
              Search, borrow, reserve and manage books from one centralized
              library.
            </p>

          </div>

          <div className="feature-card">

            <div className="feature-icon">
              👥
            </div>

            <h3>
              Study Rooms
            </h3>

            <p>
              Create study groups and learn together with your friends.
            </p>

          </div>

          <div className="feature-card">

            <div className="feature-icon">
              💬
            </div>

            <h3>
              Group Discussion
            </h3>

            <p>
              Discuss doubts, share ideas and communicate with your study
              group.
            </p>

          </div>

          <div className="feature-card">

            <div className="feature-icon">
              ⏱️
            </div>

            <h3>
              Study Timer
            </h3>

            <p>
              Stay focused using a simple Pomodoro-style study timer.
            </p>

          </div>

        </div>

      </section>

      {/* STUDY ROOMS */}
      <section className="rooms" id="rooms">

        <div className="section-heading">

          <p>
            COLLABORATIVE LEARNING
          </p>

          <h2>
            Join a Study Room
          </h2>

        </div>

        <div className="room-grid">

          <div className="room-card">

            <span className="room-status">
              ● LIVE
            </span>

            <h3>
              Java Programming
            </h3>

            <p>
              Discuss Java concepts and solve coding problems.
            </p>

            <div className="room-bottom">

              <span>
                👥 12 learners
              </span>

              <button>
                Join Room
              </button>

            </div>

          </div>

          <div className="room-card">

            <span className="room-status">
              ● LIVE
            </span>

            <h3>
              Data Structures
            </h3>

            <p>
              Practice arrays, trees, graphs and algorithms together.
            </p>

            <div className="room-bottom">

              <span>
                👥 8 learners
              </span>

              <button>
                Join Room
              </button>

            </div>

          </div>

          <div className="room-card">

            <span className="room-status">
              ● LIVE
            </span>

            <h3>
              Web Development
            </h3>

            <p>
              Learn React, Node.js and modern web development.
            </p>

            <div className="room-bottom">

              <span>
                👥 15 learners
              </span>

              <button>
                Join Room
              </button>

            </div>

          </div>

        </div>

      </section>

      {/* FOOTER */}
      <footer id="about">

        <div className="footer-logo">
          📚 Learn<span>Nest</span>
        </div>

        <p>
          A smarter place to read, collaborate and grow.
        </p>

        <p className="copyright">
          © 2026 LearnNest. All rights reserved.
        </p>

      </footer>

    </div>
  );
}

// START REACT APP
ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);