import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import http from "http";
import { Server } from "socket.io";

dotenv.config();
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: ["http://localhost:5173", "http://localhost:5174"]
  }
});

app.use(
  cors({
    origin: ["http://localhost:5173", "http://localhost:5174"]
  })
);
app.use(express.json());

const User = mongoose.model("User", new mongoose.Schema({
  name:{type:String,required:true}, email:{type:String,unique:true,required:true},
  password:{type:String,required:true}, role:{type:String,default:"student"}
},{timestamps:true}));

const Book = mongoose.model("Book", new mongoose.Schema({
  title:{type:String,required:true}, author:{type:String,required:true},
  category:{type:String,required:true}, isbn:String, description:String,
  totalCopies:{type:Number,default:1}, availableCopies:{type:Number,default:1}
},{timestamps:true}));

const Borrowing = mongoose.model("Borrowing", new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:"User"}, book:{type:mongoose.Schema.Types.ObjectId,ref:"Book"},
  issueDate:{type:Date,default:Date.now}, dueDate:Date, returnDate:Date,
  status:{type:String,default:"borrowed"}
},{timestamps:true}));

const Reservation = mongoose.model("Reservation", new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:"User"},
  book:{type:mongoose.Schema.Types.ObjectId,ref:"Book"},
  status:{type:String,default:"active"}, reservedAt:{type:Date,default:Date.now}
}));

const Room = mongoose.model("Room", new mongoose.Schema({
  name:String, topic:String, createdBy:{type:mongoose.Schema.Types.ObjectId,ref:"User"},
  members:[{type:mongoose.Schema.Types.ObjectId,ref:"User"}]
},{timestamps:true}));

function auth(req,res,next){
  try{
    const token=req.headers.authorization?.split(" ")[1];
    req.user=jwt.verify(token,process.env.JWT_SECRET); next();
  }catch(e){res.status(401).json({message:"Please login"});}
}

app.get("/",(req,res)=>res.json({message:"LearnNest API is running"}));

app.post("/api/auth/register",async(req,res)=>{
  try{
    const {name,email,password}=req.body;
    if(!name||!email||!password)return res.status(400).json({message:"All fields required"});
    if(await User.findOne({email}))return res.status(409).json({message:"Email already exists"});
    const hash=await bcrypt.hash(password,10);
    await User.create({name,email,password:hash});
    res.status(201).json({message:"Registered successfully"});
  }catch(e){res.status(500).json({message:e.message});}
});

app.put("/api/dev/make-admin", async (req, res) => {
  try {
    const user = await User.findOne({
      email: "n77i08k24i@gmail.com"
    });

    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }

    user.role = "admin";
    await user.save();

    res.json({
      message: "User promoted to admin",
      email: user.email,
      role: user.role
    });
  } catch (error) {
    res.status(500).json({
      message: error.message
    });
  }
});

app.get("/api/books",async(req,res)=>{
  const search=req.query.search||"", page=Number(req.query.page||1), limit=6;
  const filter=search?{$or:[
    {title:{$regex:search,$options:"i"}},{author:{$regex:search,$options:"i"}},
    {category:{$regex:search,$options:"i"}},{isbn:{$regex:search,$options:"i"}}
  ]}:{};
  const [books,total]=await Promise.all([
    Book.find(filter).skip((page-1)*limit).limit(limit).sort({createdAt:-1}),
    Book.countDocuments(filter)
  ]);
  res.json({books,total,page,pages:Math.ceil(total/limit)});
});

app.post("/api/books",auth,async(req,res)=>{
  if(!["admin","librarian"].includes(req.user.role))return res.status(403).json({message:"Admin/Librarian only"});
  const book=await Book.create(req.body); res.status(201).json(book);
});

app.post("/api/borrow/:id",auth,async(req,res)=>{
  const book=await Book.findById(req.params.id);
  if(!book)return res.status(404).json({message:"Book not found"});
  if(book.availableCopies<1)return res.status(400).json({message:"No copies available. Reserve it."});
  const due=new Date(); due.setDate(due.getDate()+14);
  const record=await Borrowing.create({user:req.user.id,book:book._id,dueDate:due});
  book.availableCopies--; await book.save();
  res.json({message:"Book borrowed",record});
});

app.post("/api/reserve/:id",auth,async(req,res)=>{
  const exists=await Reservation.findOne({user:req.user.id,book:req.params.id,status:"active"});
  if(exists)return res.status(400).json({message:"Already reserved"});
  await Reservation.create({user:req.user.id,book:req.params.id});
  res.json({message:"Book reserved"});
});

app.get("/api/my-books",auth,async(req,res)=>{
  res.json(await Borrowing.find({user:req.user.id}).populate("book").sort({createdAt:-1}));
});

app.put("/api/return/:id",auth,async(req,res)=>{
  const r=await Borrowing.findOne({_id:req.params.id,user:req.user.id});
  if(!r)return res.status(404).json({message:"Record not found"});
  if(r.status==="returned")return res.status(400).json({message:"Already returned"});
  r.status="returned"; r.returnDate=new Date(); await r.save();
  await Book.findByIdAndUpdate(r.book,{$inc:{availableCopies:1}});
  res.json({message:"Book returned"});
});

app.get("/api/rooms",auth,async(req,res)=>res.json(await Room.find().populate("createdBy","name")));
app.post("/api/rooms",auth,async(req,res)=>{
  const room=await Room.create({name:req.body.name,topic:req.body.topic,createdBy:req.user.id,members:[req.user.id]});
  res.status(201).json(room);
});
app.post("/api/rooms/:id/join",auth,async(req,res)=>{
  const room=await Room.findById(req.params.id); if(!room)return res.status(404).json({message:"Room not found"});
  if(!room.members.some(x=>x.toString()===req.user.id)){room.members.push(req.user.id);await room.save();}
  res.json(room);
});

io.on("connection",socket=>{
  socket.on("join-room",id=>socket.join(id));
  socket.on("message",data=>io.to(data.roomId).emit("message",data));
});

mongoose.connect(process.env.MONGO_URI).then(()=>{
  server.listen(process.env.PORT||5000,()=>console.log("LearnNest backend: http://localhost:5000"));
}).catch(e=>console.log("MongoDB error:",e.message));
