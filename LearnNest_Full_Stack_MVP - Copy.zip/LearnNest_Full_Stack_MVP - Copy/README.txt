LEARNNEST - QUICK START

1. Install Node.js LTS and MongoDB.
2. Open the project in VS Code.
3. Backend:
   cd backend
   npm install
   copy .env.example .env
   npm run dev

4. Frontend: open a SECOND terminal:
   cd frontend
   npm install
   npm run dev

5. Open the Vite URL, normally http://localhost:5173

MongoDB local URL in .env:
mongodb://127.0.0.1:27017/learnnest

Main MVP features:
- Register/login with JWT
- MongoDB books
- Search
- Borrow/return
- Reservation
- Study rooms
- Real-time Socket.IO foundation

For hackathon expansion add:
- Admin dashboard
- Full study-room chat screen
- WebRTC voice/video
- Shared notes
- Doubt module
- AI assistant
- Analytics
- Cloudinary
- Notifications
